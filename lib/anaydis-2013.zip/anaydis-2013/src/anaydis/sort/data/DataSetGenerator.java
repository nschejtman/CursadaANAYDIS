package anaydis.sort.data;

import org.jetbrains.annotations.NotNull;

import java.util.List;
import java.util.Comparator;

/**
 * Análisis y Diseño de Algoritmos
 *
 * DataSetGenerator<T> must be implemented for each type of data
 * (e.g.: StringDataSetGenerator, IntegerDataSetGenerator).
 *
 * The idea is to generate data to test different scenarios (worst case, average, random).
 * Also the DataSetGenerator<T> instanciates it's corresponding Comparator<T>.
 */
public interface DataSetGenerator<T>
{
    /**
     * Should create a new ascending List<T> (e.g.: [0,1,2,..,lenght-1])
     * Beware! List<T> may be modified.
     * @param length size of the List<T> to be returned
     * @return List<T> with T values in ascending order
     */
    @NotNull List<T> createAscending(int length);

    /**
     * Should create a new descending List<T> (e.g.: [lenght-1,..,2,1,0])
     * Beware! List<T> may be modified.
     * @param length size of the List<T> to be returned
     * @return List<T> with T values in descending order
     */
    @NotNull List<T> createDescending(int length);

    /**
     * Should create a new random List<T> (e.g.: [5,9,6,..,2,1,5])
     * Beware! List<T> may be modified.
     * @param length size of the List<T> to be returned
     * @return List<T> with T random values
     */
    @NotNull List<T> createRandom(int length);

    /**
     * Returns a {@link java.util.Comparator<T> comparator}.
     *
     * IMPLEMENTATION NOTE: This Comparator<T>  must be held as an static final
     * private field inside the implementation class, and this method must always
     * return the same instance
     *
     * @return Comparator<T> used for {@link anaydis.sort.Sorter#<T>sort(Comparator<T>, List<T>)} 
     */
    @NotNull Comparator<T> getComparator();
}
