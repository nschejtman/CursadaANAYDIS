package anaydis.sort;

import org.jetbrains.annotations.NotNull;

import java.util.Comparator;
import java.util.List;

/**
 * Análisis y Diseño de Algoritmos
 *
 * Basic Interface for all {@link Sorter sorters}.
 * Todas las implentaciones de los distintos Sorter
 * deberán implementar {@link Sorter}.
 * Implementaciones típicas:
 * <ul>
 *   <li>BubbleSorter</li>
 *   <li>InsertionSorter</li>
 *   <li>SelectionSorter</li>
 *   <li>MergeSorter</li>
 *   <li>QuickSorter</li>
 *   <li>ShellSorter</li>
 *   <li>HSorter</li>
 * </ul>
 * La clase AbstractSorter deberá ser abstracta e implementar
 * Sorter. De ahí extenderán todas las implementaciones
 * anteriormente mencionadas.
 */
public interface Sorter
{
    /**
     * Sorts the specified list into ascending order, according to the
     * natural ordering of its elements.
     * @param comparator to be used for sorting
     * @param list to be sorted.
     */
    <T> void sort(@NotNull final Comparator<T> comparator, @NotNull final List<T> list);

    /**
     * Returns the {@link SorterType type}
     * @return Sorter's type.
     */
    @NotNull SorterType getType();
}
