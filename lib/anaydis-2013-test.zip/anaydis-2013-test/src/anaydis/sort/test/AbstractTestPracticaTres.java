package anaydis.sort.test;

import anaydis.sort.Sorter;
import anaydis.sort.SorterType;
import anaydis.sort.data.DataSetGenerator;
import anaydis.sort.provider.SorterProvider;
import org.jetbrains.annotations.NotNull;

public abstract class AbstractTestPracticaTres
    extends AbstractSorterTest
{
    public void testQuickInteger50()
    {
        final SorterType type = SorterType.QUICK;
        final int size = 50;

        runTestForType(integerGen, type, size);
    }

    public void testQuickString50()
    {
        final SorterType type = SorterType.QUICK;
        final int size = 50;

        runTestForType(stringGen, type, size);
    }

    public void testShellInteger50()
    {
        final SorterType type = SorterType.SHELL;
        final int size = 50;

        runTestForType(integerGen, type, size);
    }

    public void testShellString50()
    {
        final SorterType type = SorterType.SHELL;
        final int size = 50;

        runTestForType(stringGen, type, size);
    }

    public void testHInteger2000()
    {
        final SorterType type = SorterType.H;
        final int size = 2000;

        runTestForType(integerGen, type, size);
    }

    private <T> void runTestForType(DataSetGenerator<T> generator, SorterType type, int size)
    {
        System.out.println("Testing " + type + " with size " + size + " using generator " + generator.getClass().getName());

        testSorterExists(provider, type);

        final Sorter sorter = provider.getSorterForType(type);

        testDataSetAscending(generator, sorter, size);
        testDataSetRandom(generator, sorter, size);
        testDataSetDescending(generator, sorter, size);
    }
}