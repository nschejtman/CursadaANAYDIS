package anaydis.sort.test;

import anaydis.sort.Sorter;
import anaydis.sort.SorterType;
import anaydis.sort.data.DataSetGenerator;
import anaydis.sort.provider.SorterProvider;
import org.jetbrains.annotations.NotNull;

public abstract class AbstractTestPracticaCuatro
    extends AbstractSorterTest
{
    public void testQuickCutInteger500()
    {
        final SorterType type = SorterType.QUICK_CUT;
        final int size = 500;

        runTestForType(integerGen, type, size);
    }

    public void testQuickCutString50()
    {
        final SorterType type = SorterType.QUICK_CUT;
        final int size = 50;

        runTestForType(stringGen, type, size);
    }

    public void testQuickNonRecursiveInteger500()
    {
        final SorterType type = SorterType.QUICK_NON_RECURSIVE;
        final int size = 500;

        runTestForType(integerGen, type, size);
    }

    public void testQuickNonRecursiveString50()
    {
        final SorterType type = SorterType.QUICK_NON_RECURSIVE;
        final int size = 50;

        runTestForType(stringGen, type, size);
    }

    public void testQuickMedOfThreeInteger500()
    {
        final SorterType type = SorterType.QUICK_MED_OF_THREE;
        final int size = 500;

        runTestForType(integerGen, type, size);
    }

    public void testQuickMedOfThreeString50()
    {
        final SorterType type = SorterType.QUICK_MED_OF_THREE;
        final int size = 50;

        runTestForType(stringGen, type, size);
    }

    public void testMergeInteger500()
    {
        final SorterType type = SorterType.MERGE;
        final int size = 500;

        runTestForType(integerGen, type, size);
    }

    public void testMergeString50()
    {
        final SorterType type = SorterType.MERGE;
        final int size = 50;

        runTestForType(stringGen, type, size);
    }

    public void testMergeBottomUpInteger500()
    {
        final SorterType type = SorterType.MERGE_BOTTOM_UP;
        final int size = 500;

        runTestForType(integerGen, type, size);
    }

    public void testMergeBottomUpString50()
    {
        final SorterType type = SorterType.MERGE_BOTTOM_UP;
        final int size = 50;

        runTestForType(stringGen, type, size);
    }

    private <T> void runTestForType(DataSetGenerator<T> generator, SorterType type, int size)
    {
        System.out.println("Testing " + type + " with size " + size + " using generator " + generator.getClass().getName());

        testSorterExists(provider, type);

        final Sorter sorter = provider.getSorterForType(type);

        testDataSetAscending(generator, sorter, size);
        testDataSetRandom(generator, sorter, size);
        testDataSetDescending(generator, sorter, size);
    }
}