package anaydis.sort.test;

import junit.framework.TestCase;
import anaydis.sort.Sorter;
import anaydis.sort.SorterType;
import anaydis.sort.data.DataSetGenerator;
import anaydis.sort.provider.SorterProvider;

import java.util.*;

import org.jetbrains.annotations.NotNull;

abstract class AbstractSorterTest
        extends TestCase
{
    protected final SorterProvider provider;
    protected final DataSetGenerator<String> stringGen;
    protected final DataSetGenerator<Integer> integerGen;

    public AbstractSorterTest()
    {
        this.provider = getSorterProvider();
        this.stringGen = getStringDataSetGenerator();
        this.integerGen = getIntegerDataSetGenerator();
    }

    protected abstract DataSetGenerator<String> getStringDataSetGenerator();

    protected abstract DataSetGenerator<Integer> getIntegerDataSetGenerator();

    protected abstract SorterProvider getSorterProvider();

    public void testSorterExists(@NotNull final SorterProvider provider, @NotNull final SorterType type)
    {
        try {
            final Sorter sorter = provider.getSorterForType(type);

            if(sorter == null) failSorterNotFound(type);

        } catch (IllegalArgumentException e)
        {
            failSorterNotFound(type);
        }
    }

    public <T> void testDataSetAscending(@NotNull final DataSetGenerator<T> generator, @NotNull final Sorter sorter,
                                     final int size)
    {
        System.out.println("AbstractSorterTest.ASCENDING :: " + size);

        final List<T> ascending = generator.createAscending(size);

        testDataSet(generator, sorter, size, ascending);
    }

    public <T> void testDataSetDescending(@NotNull final DataSetGenerator<T> generator, @NotNull final Sorter sorter,
                                      final int size)
    {
        System.out.println("AbstractSorterTest.DESCENDING :: " + size);

        final List<T> descending = generator.createDescending(size);

        testDataSet(generator, sorter, size, descending);
    }

    public <T> void testDataSetRandom(@NotNull final DataSetGenerator<T> generator, @NotNull final Sorter sorter,
                                  final int size)
    {
        System.out.println("AbstractSorterTest.RANDOM :: " + size);

        final List<T> random = generator.createRandom(size);

        testDataSet(generator, sorter, size, random);
    }

    private <T> void testDataSet(@NotNull final DataSetGenerator<T> generator, @NotNull final Sorter sorter,
                             final int size, @NotNull final List<T> raw)
    {
        final Comparator<T> comparator = generator.getComparator();

        assertSize(raw.size(), size);

        final List<T> sorted = new ArrayList<T>(raw);

        sorter.sort(comparator, sorted);

        assertSorted(comparator, raw, sorted);
    }

    private <T> void assertSorted(@NotNull final Comparator<T> comparator, @NotNull final List<T> raw,
                              @NotNull final List<T> sorted)
    {
        final List<T> copy = new ArrayList<T>(raw);
        Collections.sort(copy, comparator);

        final Object[] copyArray = copy.toArray();
        final Object[] sortedArray = sorted.toArray();

        if (!Arrays.equals(copyArray, sortedArray))
        {
            fail("Sorting failed! Expected sorted : \n " + Arrays.toString(copyArray) +
                    " and founded : \n" + Arrays.toString(sortedArray));
        }
    }

    private void assertSize(final int generated, int expected)
    {
        if(generated != expected)
        {
            fail("Expected DataSetGenerator to create a List of size : " + expected +
                    " but " + generated + " elements where found!");
        }
    }

    private void failSorterNotFound(SorterType type)
    {
        fail("Sorter for type : " + type + " not found on provider!");
    }
}
