package anaydis.sort.test;

import anaydis.sort.Sorter;
import anaydis.sort.SorterType;
import anaydis.sort.data.DataSetGenerator;
import anaydis.sort.provider.SorterProvider;
import org.jetbrains.annotations.NotNull;

public abstract class AbstractTestPracticaDos
    extends AbstractSorterTest
{
    public void testBubbleInteger50()
    {
        final SorterType type = SorterType.BUBBLE;
        final int size = 50;

        runTestForType(integerGen, type, size);
    }

    public void testBubbleString50()
    {
        final SorterType type = SorterType.BUBBLE;
        final int size = 50;

        runTestForType(stringGen, type, size);
    }

    public void testInsertionInteger50()
    {
        final SorterType type = SorterType.INSERTION;
        final int size = 50;

        runTestForType(integerGen, type, size);
    }

    public void testInsertionString50()
    {
        final SorterType type = SorterType.INSERTION;
        final int size = 50;

        runTestForType(stringGen, type, size);
    }

    public void testSelectionInteger50()
    {
        final SorterType type = SorterType.SELECTION;
        final int size = 50;

        runTestForType(integerGen, type, size);
    }

    public void testSelectionString50()
    {
        final SorterType type = SorterType.SELECTION;
        final int size = 50;

        runTestForType(stringGen, type, size);
    }

    private <T> void runTestForType(DataSetGenerator<T> generator, SorterType type, int size)
    {
        System.out.println("Testing " + type + " with size " + size + " using generator " + generator.getClass().getName());

        testSorterExists(provider, type);

        final Sorter sorter = provider.getSorterForType(type);

        testDataSetAscending(generator, sorter, size);
        testDataSetRandom(generator, sorter, size);
        testDataSetDescending(generator, sorter, size);
    }
}
