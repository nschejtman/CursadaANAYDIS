
// ...............................................................................................................................
//
// (C) Copyright  2011/2013 TekGenesis.  All Rights Reserved
// THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF TekGenesis.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
// ...............................................................................................................................

package anaydis.sort.gui;

import org.jetbrains.annotations.NotNull;

/**
 * Análisis y Diseño de Algoritmos.
 *
 * <p>Interface to provide holding support for {@link SorterListener listeners}</p>
 */
public interface ObservableSorter {

    //~ Methods ..................................................................................................................

    /**
     * Adds the given SorterListener.
     *
     * @param  listener  to be added
     */
    void addSorterListener(@NotNull final SorterListener listener);

    /**
     * Removes the given SorterListener.
     *
     * @param  listener  to be removed
     */
    void removeSorterListener(@NotNull final SorterListener listener);
}
