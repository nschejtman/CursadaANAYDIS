
// ...............................................................................................................................
//
// (C) Copyright  2011/2013 TekGenesis.  All Rights Reserved
// THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF TekGenesis.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
// ...............................................................................................................................

package anaydis.animation.sort.gui;

import java.awt.*;
import java.io.IOException;
import java.net.URL;
import java.util.Enumeration;
import java.util.Vector;

import javax.swing.*;

import anaydis.animation.core.AnimationController;
import anaydis.animation.model.SortDataModel;
import anaydis.animation.sort.SortAnimation;

import org.jetbrains.annotations.NotNull;

class SortToolBar extends JToolBar {

    //~ Instance Fields ..........................................................................................................

    private JComboBox      dataChoices;
    private AbstractButton runButton;
    private JComboBox      sortChoices;
    private JSlider        speedSlider;
    private AbstractButton stopButton;

    //~ Constructors .............................................................................................................

    public SortToolBar(@NotNull final JComboBox sortChoices) {
        super(JToolBar.HORIZONTAL);

        this.sortChoices = sortChoices;
        add(sortChoices);

        final Vector<SortDataModel> models = new Vector<SortDataModel>(SortAnimation.getModels());
        dataChoices = new JComboBox(models);
        dataChoices.setMaximumRowCount(models.size());
        add(dataChoices);

        runButton  = makeButton("run", "pause", AnimationController.RUN_COMMAND);
        stopButton = makeButton("stop", null, AnimationController.STOP_COMMAND);
        addSeparator();
        speedSlider = new JSlider(0, AnimationController.MAX_SPEED, AnimationController.MAX_SPEED / 4);
        speedSlider.setMajorTickSpacing(AnimationController.MAX_SPEED / 4);
        speedSlider.setMinorTickSpacing(1);
        speedSlider.setPaintTicks(true);
        add(speedSlider);

        setFloatable(false);
        setRollover(true);
    }

    //~ Methods ..................................................................................................................

    public void pause() { runButton.setSelected(false); }

    public void setControler(AnimationController animationController) {
        speedSlider.addChangeListener(animationController);
        runButton.addActionListener(animationController);
        stopButton.addActionListener(animationController);
        dataChoices.addItemListener(animationController);
        sortChoices.addItemListener(animationController);
    }

    public SortDataModel getData() { return (SortDataModel) dataChoices.getSelectedItem(); }

    public Dimension getMaximumSize() { return new Dimension(Integer.MAX_VALUE, getPreferredSize().height); }

    public JSlider getSlider() { return speedSlider; }

    protected AbstractButton makeButton(String imageName, String selectedImageName, String actionCommand) {
        // Create and initialize the button.
        AbstractButton button;
        if (selectedImageName == null) button = new JButton();
        else {
            button = new JToggleButton();
            button.setSelectedIcon(getImageIcon(selectedImageName));
        }
        button.setActionCommand(actionCommand);
        button.setIcon(getImageIcon(imageName));
        button.setBorderPainted(false);
        add(button);
        return button;
    }  // end method makeButton

    void enableControls(boolean running) {
        dataChoices.setEnabled(!running);
        if (!running) runButton.setSelected(false);
        stopButton.setEnabled(running);
    }

    private ImageIcon getImageIcon(String imageName) {
        return new ImageIcon(getClass().getResource("/images/" + imageName + ".png"));
    }
}
