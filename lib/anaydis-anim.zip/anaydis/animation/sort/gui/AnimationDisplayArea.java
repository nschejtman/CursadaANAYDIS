
// ...............................................................................................................................
//
// (C) Copyright  2011/2013 TekGenesis.  All Rights Reserved
// THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF TekGenesis.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
// ...............................................................................................................................

package anaydis.animation.sort.gui;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ItemEvent;

import javax.swing.*;
import javax.swing.event.ChangeEvent;

import anaydis.animation.core.AnimationController;
import anaydis.animation.sort.SortAnimation;

import org.jetbrains.annotations.NotNull;

public class AnimationDisplayArea extends JComponent implements AnimationController {

    //~ Instance Fields ..........................................................................................................

    private final JComboBox animations;

    private final Main      main;
    private final Dimension minimum;

    private boolean           running;
    private SortAnimation     sortAnimation;
    private final SortToolBar toolBar;

    //~ Constructors .............................................................................................................

    AnimationDisplayArea(@NotNull final Main main, @NotNull final SortToolBar toolBar, @NotNull final JComboBox animations,
                         final int panels) {
        this.main       = main;
        this.toolBar    = toolBar;
        this.minimum    = new Dimension(700, 500 / panels);
        this.animations = animations;
        setMinimumSize(minimum);
        setBorder(BorderFactory.createLoweredBevelBorder());
        setBackground(Color.WHITE);
        setOpaque(true);
        toolBar.setControler(this);
    }

    //~ Methods ..................................................................................................................

    public void actionPerformed(ActionEvent e) {
        String cmd = e.getActionCommand();
        if (cmd.equals(AnimationController.RUN_COMMAND)) {
            if (running && sortAnimation != null) sortAnimation.pause();
            else {
                running = true;
                initAnimation();
                sortAnimation.setSpeed(toolBar.getSlider().getValue());
                sortAnimation.start();
            }
        }
        else if (cmd.equals(AnimationController.STOP_COMMAND)) {
            if (running) sortAnimation.pause();

            running = false;
            initAnimation();
            sortAnimation.doStop();
        }

        if (main.anyRunning() == running) {
            toolBar.enableControls(running);
            animations.setEnabled(!running);
        }
    }  // end method actionPerformed

    public void end() {
        running = false;

        if (!main.anyRunning()) toolBar.enableControls(running);

        animations.setEnabled(!running);
    }

    public void itemStateChanged(ItemEvent e) {
        if (e.getStateChange() == ItemEvent.SELECTED) initAnimation();
    }

    public void pause() { toolBar.pause(); }

    public void stateChanged(ChangeEvent e) {
        JSlider slider = toolBar.getSlider();
        if (sortAnimation != null && e.getSource() == slider) sortAnimation.setSpeed(slider.getValue());
    }

    @NotNull public Dimension getDisplayAreaSize() { return getSize(); }

    public boolean isRunning() { return running; }

    public Dimension getPreferredSize() { return minimum; }

    public SortAnimation getSortAlgorithm() { return (SortAnimation) animations.getSelectedItem(); }

    protected void paintComponent(@NotNull final Graphics graphics) {
        graphics.setColor(Color.WHITE);

        final int width  = getWidth();
        final int height = getHeight();

        graphics.fillRect(0, 0, width, height);

        if (sortAnimation != null)
            sortAnimation.paintArray((Graphics2D) graphics.create(FRAME_SPACE, FRAME_SPACE, width - 2 * FRAME_SPACE,
                                                                  height - 2 * FRAME_SPACE));
    }

    void initAnimation() {
        sortAnimation = getSortAlgorithm();
        sortAnimation.init(this, (getSize().width - 2 * FRAME_SPACE - 4) / 16);
        // sortAnimation.init(this, 10);
        sortAnimation.setData(toolBar.getData());
    }

    //~ Static Fields ............................................................................................................

    private static final int FRAME_SPACE = 5;
}
