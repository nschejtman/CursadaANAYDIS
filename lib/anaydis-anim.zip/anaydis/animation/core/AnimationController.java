
// ...............................................................................................................................
//
// (C) Copyright  2011/2013 TekGenesis.  All Rights Reserved
// THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF TekGenesis.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
// ...............................................................................................................................

package anaydis.animation.core;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import org.jetbrains.annotations.NotNull;

public interface AnimationController extends ChangeListener, ActionListener, ItemListener {

    //~ Methods ..................................................................................................................

    void actionPerformed(ActionEvent e);
    void end();
    void itemStateChanged(ItemEvent e);
    void pause();
    void repaint();
    void stateChanged(ChangeEvent e);
    @NotNull Dimension getDisplayAreaSize();

    //~ Static Fields ............................................................................................................

    String RUN_COMMAND = "RUN";

    String STOP_COMMAND = "STOP";

    int MAX_SPEED = 20;
}
