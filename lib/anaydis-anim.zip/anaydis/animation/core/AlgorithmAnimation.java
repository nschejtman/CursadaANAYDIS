
// ...............................................................................................................................
//
// (C) Copyright  2011/2013 TekGenesis.  All Rights Reserved
// THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF TekGenesis.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
// ...............................................................................................................................

package anaydis.animation.core;

import java.awt.*;

import javax.swing.*;

public abstract class AlgorithmAnimation implements Runnable {

    //~ Instance Fields ..........................................................................................................

    protected boolean animating;

    protected AnimationController controller;
    protected boolean             paused;

    protected int     speed         = 1;
    protected boolean stopRequested;

    private boolean painting;
    private Thread  thread;
    private boolean waitForPaintingToEnd;

    //~ Methods ..................................................................................................................

    public void doSleep(int time) {
        if (stopRequested) throw new StopRequestedException();

        beginPainting();
        controller.repaint();
        doWait(time);
    }

    public void doStop() { stopRequested = true; }

    public synchronized void pause() {
        paused = !paused;
        if (!paused) notify();
    }

    public void run() {
        try {
            doRun();
            controller.repaint();
        }
        catch (StopRequestedException ignore) {}
        catch (Exception exception) {
            System.out.println("An error occurred during sorting execution: exception printed to console!");
            exception.printStackTrace();
        }
        controller.end();
        thread = null;
    }

    public void start() {
        if (thread == null) {
            thread = new Thread(this);
            thread.start();
        }
    }

    public synchronized void step() { notify(); }

    public void setSpeed(int speed) {
        if (speed < 0 || speed > AnimationController.MAX_SPEED) throw new IllegalArgumentException("Invalid speed! : " + speed);

        this.speed = speed;
    }

    protected abstract void doRun();

    protected synchronized void finishPainting() {
        painting = false;
        if (waitForPaintingToEnd) notify();
    }

    private void beginPainting() { painting = true; }

    /** @param  time:  microseconds at fastest speed, milliseconds at slowest */
    private synchronized void doWait(int time) {
        try {
            if (paused) wait();
            else if (speed == 0 && !animating) {
                controller.pause();
                paused = true;
                wait();
            }
            else {
                int timeout = (time * speedScale[speed]) / 1000;
                if (timeout <= 0) timeout = 1;
                wait(timeout);
                if (timeout > 20) {
                    while (painting) {
                        waitForPaintingToEnd = true;
                        wait();
                        waitForPaintingToEnd = false;
                    }
                }
            }
        }
        catch (InterruptedException ignored) {}
    }  // end method doWait

    //~ Static Fields ............................................................................................................

    protected static Color BLUE        = new Color(15, 20, 170);
    protected static Color LIGHT_BLUE  = new Color(50, 150, 205);
    protected static Color RED         = new Color(170, 20, 20);
    protected static Color LIGHT_RED   = new Color(200, 100, 100);
    protected static Color GREEN       = new Color(15, 170, 20);
    protected static Color LIGHT_GREEN = new Color(50, 205, 150);
    protected static Color MAIN        = new Color(100, 150, 200);
    protected static Color LIGHT_MAIN  = new Color(180, 200, 220);
    protected static Color TMAIN       = new Color(100, 150, 200, 100);
    protected static Color LIGHT_TMAIN = new Color(180, 200, 220, 100);

    protected static final Stroke normalStroke = new BasicStroke(2);

    protected static int[] speedScale = {
        5000, 1000, 750, 500, 300, 200, 150,
        100, 90, 75, 50, 30, 20, 15,
        10, 9, 7, 5, 3, 2, 1
    };

    static {
        assert speedScale.length == AnimationController.MAX_SPEED + 1 : "Bad Speed scale array";
    }

    //~ Inner Classes ............................................................................................................

    public static final class StopRequestedException extends RuntimeException {}
}
