
// ...............................................................................................................................
//
// (C) Copyright  2011/2013 TekGenesis.  All Rights Reserved
// THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF TekGenesis.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
// ...............................................................................................................................

package anaydis.animation.model;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import org.jetbrains.annotations.NotNull;

public class RandomDataModel extends SortDataModel {

    //~ Methods ..................................................................................................................

    public List<Integer> create(int size) {
        final List<Integer> result = initializeEmptyList(size);

        fill(result, size, size);

        return result;
    }

    public String toString() { return "Random"; }

    protected void fill(@NotNull final List<Integer> result, int lengthToFill, int size) {
        final Random random = new java.util.Random(1);

        for (int i = 0; i < lengthToFill; i++)
            result.set(i, random.nextInt(lengthToFill) * (size / lengthToFill) + 1);
    }
}
