
// ...............................................................................................................................
//
// (C) Copyright  2011/2013 TekGenesis.  All Rights Reserved
// THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF TekGenesis.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
// ...............................................................................................................................

package anaydis.animation.model;

import java.util.ArrayList;
import java.util.List;

public class AscendingDataModel extends SortDataModel {

    //~ Instance Fields ..........................................................................................................

    private int begin;

    //~ Constructors .............................................................................................................

    public AscendingDataModel(int begin) { this.begin = begin; }

    //~ Methods ..................................................................................................................

    public List<Integer> create(int size) {
        final List<Integer> result = initializeEmptyList(size);

        for (int i = 0; i < size; i++)
            result.set(i, (i + begin) % size);

        return result;
    }

    public String toString() { return begin == 0 ? "Ascending" : "~Ascending"; }
}
