
// ...............................................................................................................................
//
// (C) Copyright  2011/2013 TekGenesis.  All Rights Reserved
// THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF TekGenesis.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
// ...............................................................................................................................

package anaydis.animation.model;

import java.util.ArrayList;
import java.util.List;

public class TriangleDataModel extends SortDataModel {

    //~ Instance Fields ..........................................................................................................

    private boolean inverted;

    //~ Constructors .............................................................................................................

    public TriangleDataModel(boolean inverted) { this.inverted = inverted; }

    //~ Methods ..................................................................................................................

    public List<Integer> create(int size) {
        final List<Integer> result = initializeEmptyList(size);

        final int m = size / 2;

        for (int i = 0; i < m; i++) {
            if (inverted) result.set(i, size - i * 2 - 1);
            else result.set(i, i * 2 + 1);

            result.set(size - i - 1, result.get(i) + 1);
        }

        return result;
    }

    public String toString() { return inverted ? "Inverted Triangle" : "Triangle"; }
}
