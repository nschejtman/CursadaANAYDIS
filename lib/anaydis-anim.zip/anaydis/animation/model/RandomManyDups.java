
// ...............................................................................................................................
//
// (C) Copyright  2011/2013 TekGenesis.  All Rights Reserved
// THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF TekGenesis.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
// ...............................................................................................................................

package anaydis.animation.model;

import java.util.ArrayList;
import java.util.List;

public class RandomManyDups extends RandomDataModel {

    //~ Methods ..................................................................................................................

    public List<Integer> create(int size) {
        final List<Integer> result = initializeEmptyList(size);

        fill(result, 6, size);

        for (int i = 6; i < size; i++)
            result.set(i, result.get(i - 6));

        return result;
    }

    public String toString() { return "Many Dups"; }
}
