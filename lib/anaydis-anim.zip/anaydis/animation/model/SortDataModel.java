
// ...............................................................................................................................
//
// (C) Copyright  2011/2013 TekGenesis.  All Rights Reserved
// THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF TekGenesis.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
// ...............................................................................................................................

package anaydis.animation.model;

import java.util.ArrayList;
import java.util.List;

public abstract class SortDataModel {

    //~ Methods ..................................................................................................................

    public abstract List<Integer> create(final int size);

    protected List<Integer> initializeEmptyList(final int size) {
        final List<Integer> list = new ArrayList<Integer>(size);

        for (int i = 0; i < size; i++)
            list.add(null);

        return list;
    }
}
