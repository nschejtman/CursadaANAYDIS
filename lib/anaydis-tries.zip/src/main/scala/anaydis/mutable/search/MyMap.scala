package anaydis.mutable.search

import java.util.NoSuchElementException

trait MyMap[K,V] {
  def get(k:K):V
  def put(k:K, v:V):Unit
  def remove(k:K):Unit
  def size:Int
  def isEmpty = size == 0
  def contains(k:K):Boolean
  def notFound(k: K) = throw new NoSuchElementException(s"Key $k not found")
  def unreachable(idx: Int) = throw new IndexOutOfBoundsException
}
