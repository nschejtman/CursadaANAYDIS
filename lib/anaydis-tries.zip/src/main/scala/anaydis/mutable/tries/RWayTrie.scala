package anaydis.mutable.tries

import anaydis.mutable.search.MyMap

class RWayTrie[V] extends MyMap[String, V] {

    class Node {
        var value: Option[V] = None
        val next: Array[Node] = new Array[Node](256)
    }

    var size = 0
    var head: Node = null

    def contains(k: String): Boolean = {
        validateKey(k)
        val n = find(head, k)
        n != null && n.value == None
    }

    def get(k: String): V = {
        validateKey(k)
        val n = find(head, k)
        if (n == null || n.value == None) notFound(k)
        n.value.get
    }

    def put(k: String, v: V) = {
        validateKey(k); head = doPut(k, v, head)
    }

    def validateKey(k: String): Unit = if (k == null) throw new IllegalArgumentException("Empty String")

    def find(n: Node, k: String): Node =
        if (n == null) null
        else if (k.length == 0) n
        else find(n.next(k.charAt(0)), k.substring(1))

    def doPut(k: String, v: V, n: Node = null): Node = {
        val node = if (n == null) new Node() else n
        if (k.length != 0) {
            val l = k.charAt(0)
            node.next(l) = doPut(k.substring(1), v, node.next(l))
        }
        else {
            if (node.value == None) size += 1
            node.value = Some(v)
        }
        node
    }

    def remove(k: String) = {
        validateKey(k); head = doRemove(k, head)
    }

    def doRemove(k: String, n: Node): Node =
        if (n == null) null
        else if (k.length != 0) {
            val l = k.charAt(0)
            n.next(l) = doRemove(k.substring(1), n.next(l))
            n
        }
        else {
            if (n.value != None) {
                size -= 1
                n.value = None
            }
            if (n.next.exists(_ != null)) n else null
        }
}

object RWayTrieMain extends App {
  val trie = new RWayTrie[Int]()
  trie.put("AB", 10)
  trie.put("ABBA", 1001)
  trie.put("CABA", 2101)

  println(trie.contains("AB"))
  println(trie.contains("CAB"))

  println(trie.get("AB"))
  println(trie.get("ABBA"))
  println(trie.get("CABA"))

  trie.remove("AB")
  println(trie.contains("AB"))

}

