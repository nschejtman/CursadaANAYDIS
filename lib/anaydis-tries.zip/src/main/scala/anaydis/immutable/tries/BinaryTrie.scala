package anaydis.immutable.tries

import anaydis.immutable.search.MyMap

object BinaryTrie {
  
  trait BinaryTrie[+V] extends MyMap[Int, V] {
      def contains(k: Int) = find(k, 0).isInstanceOf[Leaf[_]]
  
      def get(k: Int) = find(k, 0) match {
          case l: Leaf[V] => l.value
          case _ => notFound(k)
      }
  
      def put[V1 >: V](k: Int, v: V1): MyMap[Int, V1] = doPut(k, v, 0)
  
      def remove(k: Int) = doRemove(k, 0)
  
      def bitAt(value: Int, n: Int): Boolean = (value & (1 << n)) != 0
  
      def find(k: Int, bit: Int): BinaryTrie[V]
  
      def doPut[V1 >: V](k: Int, v: V1, bit: Int): BinaryTrie[V1]
  
      def doRemove(k: Int, bit: Int): BinaryTrie[V]
  
  }
  
  private case class INode[+V](left: BinaryTrie[V] = Empty, right: BinaryTrie[V] = Empty) extends BinaryTrie[V] {
  
      def size = left.size + right.size
  
      def find(k: Int, bit: Int): BinaryTrie[V] = {
          val n = if (bitAt(k, bit)) right else left
          n.find(k, bit + 1)
      }
  
      def doPut[V1 >: V](k: Int, v: V1, bit: Int): BinaryTrie[V1] =
          if (bitAt(k, bit)) INode(left, right.doPut(k, v, bit + 1))
          else INode(left.doPut(k, v, bit + 1), right)
  
      def doRemove(k: Int, bit: Int): BinaryTrie[V] =
          if (bitAt(k, bit)) {
              val n = right.doRemove(k, bit + 1)
              if (n == Empty && left == Empty) Empty else INode(left, n)
          }
          else {
              val n = left.doRemove(k, bit + 1)
              if (n == Empty && right == Empty) Empty else INode(n, right)
          }
  }
  
  private case class Leaf[+V](key: Int, value: V) extends BinaryTrie[V] {
      def size = 1
  
      def find(k: Int, bit: Int) = if (k == key) this else Empty
  
      def doPut[V1 >: V](k: Int, v: V1, bit: Int): BinaryTrie[V1] =
          if (k == key) Leaf(k, v)
          else {
              val c = bitAt(key, bit)
              val n = bitAt(k, bit)
              if (c == n) {
                  val node = doPut(k, v, bit + 1)
                  if (n) INode(Empty, node) else INode(node, Empty)
              }
              else if (n) INode(this, Leaf(k, v)) else INode(Leaf(k, v), this)
          }
  
      def doRemove(k: Int, bit: Int): BinaryTrie[V] = if (k == key) Empty else this
  
      override def toString = s"$key->$value"
  }
  
  private object Empty extends BinaryTrie[Nothing] {
      def size = 0
  
      def find(k: Int, bit: Int) = this
  
      def doPut[V1](k: Int, v: V1, bit: Int): BinaryTrie[V1] = Leaf(k, v)
  
      def doRemove(k: Int, bit: Int): BinaryTrie[Nothing] = this
  
      override def toString = "∅"
  }
  
  val empty : BinaryTrie[Nothing] = Empty
}

object BinaryTrieMain extends App {
  val b1 = BinaryTrie.empty
  val b2 = b1.put(10, "A")
  val b3 = b2.put(2, "B")
  val b4 = b3.put(12, "AB")

  for (b <- Array(b1, b2, b3, b4))
    println(b)

  println(b4.contains(10))
  println(b4.contains(21))

  println(b4.get(10))
  println(b4.get(2))
  println(b4.get(12))

  println(b4.remove(10).contains(10))

  println(b2.remove(12).remove(2))
}
