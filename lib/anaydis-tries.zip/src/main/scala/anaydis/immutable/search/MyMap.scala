package anaydis.immutable.search

import java.util.NoSuchElementException

trait MyMap[K,+V] {
  def get(k:K):V
  def put[V1 >: V](k:K, v:V1):MyMap[K,V1]
  def remove(k:K):MyMap[K,V]
  def size:Int
  def isEmpty = size == 0
  def contains(k:K):Boolean
  def notFound(k: K) = throw new NoSuchElementException(s"Key $k not found")
  def unreachable = throw new IndexOutOfBoundsException
}
